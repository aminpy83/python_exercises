class Animal():
     

    def __init__(self, name, species, age, sound):
        self.name = name
        self.species = species
        self.age = age
        self.sound = sound
        self.zoo_name = 'baghe vahshe N' 

    def make_sound(self, sound):
        print (self.sound)

    def info(self):
        print(f"Name = {self.name} , Species = {self.species} , Age = {self.age} , Sound = {self.sound}")

    def __str__(self):
       return f"Animal mored nazar is {self.name} from {self.species} age: {self.age}  sound: {self.sound}  "
        

class Bird(Animal):
    def __init__(self, name, species, age, sound, wing_span):
        Animal.__init__(self, name, species, age, sound)
        #self.species = "Bird"
        self.wing_span = wing_span

    def make_sound(self):
        print (self.sound)

lion = Animal('lion', 'mammal', 10, 'Aaaaa' )
lion.info()
print()
print('----------------------')
print(lion)
print()
print('---------------------')
#joj = Bird('jojo',"Bird", 10, 'jik', 12 )
#print(joj)