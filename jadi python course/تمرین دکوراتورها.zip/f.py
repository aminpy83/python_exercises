import time


def timer(f):
    def wrapper():
        time1 = time.time()
        f()
        time2 = time.time()
        
        print (f"time: {time2 - time1}  seconds")
        return
    return wrapper

@timer
def t():
    mylist = []
    n = int(input('n=?  '))
    for x in range(1,n):
        mylist.append(x)
    print (mylist)
    return

t()