import csv

class Task():
    def __init__(self, name, information, priorities):
        self.name = name
        self.information = information
        self.priorities = priorities

    def get_csv(self):
        with open('todo_list.csv', 'a', newline='') as file:
            writer = csv.DictWriter(file, fieldnames=['name', 'information', 'priorities'])
            writer.writerow({'name': self.name, 'information': self.information, 'priorities': self.priorities})


class TodoList():
    def __init__(self):
        self.tasks = []

    def delete_task(self, name):
        
        tasks_to_keep = []
        task_found = False
        
        with open('todo_list.csv', 'r', newline='') as file:
            reader = csv.DictReader(file)
            for row in reader:
                if row['name'] != name:
                    tasks_to_keep.append(row)
                else:
                    task_found = True
        
        if not task_found:
            print(f"Task '{name}' not found.")
            return
        
        with open('todo_list.csv', 'w', newline='') as file:
            writer = csv.DictWriter(file, fieldnames=['name', 'information', 'priorities'])
            writer.writeheader()
            writer.writerows(tasks_to_keep)
        
        print(f"Task '{name}' has been deleted.")

    def add_task(self, name, information, priorities):
        with open('todo_list.csv', 'r', newline='') as file:
            reader = csv.DictReader(file)
            for row in reader:
                if row['name'] == name:
                    print('task already exists')
                    return
        task = Task(name, information, priorities)
        task.get_csv()
        self.tasks.append(task)

    def get_all_tasks(self):
        self.tasks = []  
        with open('todo_list.csv', 'r') as file:
            reader = csv.DictReader(file)
            for row in reader:
                self.tasks.append(row)
        
        def get_priority(task):
            try:
                return int(task['priorities'])
            except (ValueError, TypeError):
                return 999
        
        self.tasks.sort(key=get_priority)
        
        
        if not self.tasks:
            print("No tasks found.")
            return
        
        print("\n                    ===== TODO LIST =====")
        print(f"{'#':<3} {'TASK NAME':<20} {'INFORMATION':<30} {'PRIORITY':<10}")
        print("-" * 65)
        
        for i, task in enumerate(self.tasks, 1):
            print(f"{i:<3} {task['name']:<20} {task['information']:<30} {task['priorities']:<10}")
        
        print("=" * 65)
        return
