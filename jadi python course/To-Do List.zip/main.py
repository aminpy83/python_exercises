from f import Task, TodoList


import csv
todos = []

with open('todo_list.csv', 'r') as file:
    reader = csv.DictReader(file)
    for row in reader:
        try:
            # Try to convert priorities to int, default to 0 if it fails
            priority = int(row['priorities'])
        except (ValueError, TypeError):
            # If conversion fails, use 0 as default priority
            priority = 0
            
        todos.append({row['name']: {'information': row['information'], 'priorities': priority}})
    
    todos = sorted(todos, key=lambda x: x[list(x.keys())[0]]['priorities'])
    
    for todo in todos:
        
        name = list(todo.keys())[0]
        information = todo[name]['information']
        priorities = todo[name]['priorities']

#amin = TodoList()
#amin.add_task('amin', 'amin', 1)
#amin.delete_task('amin')
#amin.get_all_tasks()
print(  """             salam 
menu:
1. add task
2. delete task
3. show all tasks
4. exit      

!important:please enter the number of the choice between 1 to 4
      otherwise the program will be restarted
""")
choice = int(input('enter your choice: '))
while choice not in range(1,5):
            print('invalid choice')
            choice = input('enter your choice: ')

chosen_task = TodoList()

if choice == 1:
    name = input('enter the name of the task: ')
    information = input('enter the information of the task: ')
    print('note: priority must be a Natural number and no matter if it is repetitive or not')
    priorities = input('enter the priorities of the task: ')
    chosen_task.add_task(name, information, priorities)

if choice == 2:
    name = input('enter the name of the task: ')
    chosen_task.delete_task(name)

if choice == 3:
    chosen_task.get_all_tasks()

if choice == 4:
    print('exiting the program bye byee')
    exit()











