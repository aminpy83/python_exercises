from mylibrary import library

library = library.library()

if __name__ == "__main__":
    print("program is running mostaghim")
    print()
    while 1:
        print("here is the Library Menu")
        print("1.Add")  # add_book
        print("2.Search")  # search_book
        print("3.Remove")  # remove_book
        print("4.All Books")  # show_books

        customer = input(
            "Please choose between 1-4 otherwise the program will be closed \n"
        )

        if customer == "1":
            title = input("Book title: ")
            author = input("Who's the author: ")
            library.add_book(title, author)

        elif customer == "2":
            title = input("Book title: ")
            library.search_book(title)

        elif customer == "3":
            title = input("Book title: ")
            library.remove_book(title)

        elif customer == "4":
            library.show_books()

        else:
            break
