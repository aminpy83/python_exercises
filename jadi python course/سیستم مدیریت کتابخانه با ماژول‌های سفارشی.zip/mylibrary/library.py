class library:
    def __init__(self):
        self.b_list = []

    def add_book(self, title, author):
        self.b_list.append({"title": title, "author": author})
        print(f"{title} from {author} added ")
        print("--------------------------------------------")


    def remove_book(self, title):
        if not self.b_list:
            print('not founded')
        for book in self.b_list:
            if book["title"] == title:
                self.b_list.remove(book)
                print("Removed successfully")
                print("--------------------------------------------")
                return
            print("not founded")
        print("--------------------------------------------")
        

    def search_book(self, title):
        for book in self.b_list:
            if book["title"] == title:
                print(f"found your book {book["title"]} by {book["author"]}")
            else:
                print("not founded")
        print("--------------------------------------------")
        

    def show_books(self):
        if not self.b_list:
            print("library is empty!")
        for book in self.b_list:
            print(f"{book['title']} by {book['author']}")
        print("--------------------------------------------")


