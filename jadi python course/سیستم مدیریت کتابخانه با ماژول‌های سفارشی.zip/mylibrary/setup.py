from setuptools import setup

setup(
    name="mylibrary", 

    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.13',  #نسخه پایتون
)