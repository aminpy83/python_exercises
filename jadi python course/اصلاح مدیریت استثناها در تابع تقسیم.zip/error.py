def divide(a, b):
    result = a / b
    return result





while True:

    try:
        num1 = int(input("Enter first number: "))
        num2 = int(input("Enter second number: "))
        print("Result:", divide(num1, num2))

    except ZeroDivisionError as zero_err:
        print("Cannot be divided to zero")

    except ValueError as val_err:
        print("Inavalid input ")

    finally:
        print( "برنامه با موفقیت اجرا شد!")
        print( "barname ba movafaghiat ejra shod!")
        print("----------------------------------------------")
                                                                #break         برای اتمام برنامه