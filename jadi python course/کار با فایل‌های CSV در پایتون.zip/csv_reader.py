import csv


with open('1741502118270796.csv', 'r') as file:
    csv_reader = csv.reader(file)
    x = []
    total_price = ['Total Price']

    next(csv_reader, None)
    for row in csv_reader:
        total_price.append(int(row[1]) * int(row[2]))

    file.seek(0)
    for row in csv_reader:
        x.append(row)
    print(x)
    print(total_price)

for i in range(len(x)):
    x[i].append(total_price[i])

with open('new_csv.csv', 'w') as file:
    csv_writer = csv.writer(file)
    csv_writer.writerows(x)
    




