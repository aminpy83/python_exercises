import requests
import bs4 
url = "https://en.wikipedia.org/wiki/MATE_(desktop_environment)"
data = requests.get(url)

soup = bs4.BeautifulSoup(data.text, 'html.parser')

title = soup.select('title')
print(title)
print('------------------------')


special = [soup.find('img',  class_="mw-file-element")]
print(special)
print('------------------------')

links = []
images = soup.find_all('img')

for img in images:
    src = img.get('src')
    if src:
        links.append(src)


print(links)


#source link: https://en.wikipedia.org/wiki/MATE_(desktop_environment)
